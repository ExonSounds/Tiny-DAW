"""Start Tiny DAW:  python main.py [project.json | audio and MIDI files to add...]"""
import sys

from PySide6.QtWidgets import QApplication

from daw.ui.main_window import MainWindow
from daw.ui.theme import apply_dark_palette


def main():
    app = QApplication(sys.argv)
    apply_dark_palette(app)
    window = MainWindow()
    window.show()
    for path in sys.argv[1:]:
        if path.lower().endswith(".json"):
            window.open_project_file(path)
        else:
            window.timeline.add_file(path)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
