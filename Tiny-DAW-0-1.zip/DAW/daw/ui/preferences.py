"""Options from the Options menu, remembered between runs (QSettings).

Most of them trade detail for lower CPU use; see main_window.build_options_menu().
"""
from dataclasses import dataclass, fields

from PySide6.QtCore import QSettings

SETTINGS = ("TinyDAW", "TinyDAW")
BUFFER_SIZES = (0, 128, 256, 512, 1024, 2048)  # frames per audio buffer; 0 = the driver's own setting
REFRESH_RATES = (60, 30, 15)  # screen updates per second for the playhead and meters


@dataclass
class Preferences:
    driver_type: str = "ASIO"  # see audio/devices.py DRIVER_TYPES; a missing type falls back to another
    device_name: str = ""  # output device to open; "" or a missing one = the driver type's default
    wasapi_exclusive: bool = False
    buffer_size: int = 512  # an explicit size: some drivers' own default changes with whatever was used last
    level_meters: bool = True
    loudness_meters: bool = True
    refresh_fps: int = 60
    metronome: bool = False  # on/off (its sounds: metronome_dialog.py)

    @classmethod
    def load(cls):
        stored = QSettings(*SETTINGS)
        prefs = cls()
        for f in fields(cls):
            setattr(prefs, f.name, stored.value(f"options/{f.name}", getattr(prefs, f.name), type=type(f.default)))
        if prefs.buffer_size not in BUFFER_SIZES:
            prefs.buffer_size = 0
        if prefs.refresh_fps not in REFRESH_RATES:
            prefs.refresh_fps = 60
        return prefs

    def save(self):
        stored = QSettings(*SETTINGS)
        for f in fields(self):
            stored.setValue(f"options/{f.name}", getattr(self, f.name))
