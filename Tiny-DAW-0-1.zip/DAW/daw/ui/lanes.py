"""The editor's lanes from top to bottom, shared by the timeline, the lane panel and the overview
so they always line up:

    a header lane for each group, right above its tracks (GROUP_H tall)
    a lane for each track, as tall as the track; none for the tracks of a folded group
    the master lane at the bottom (TRACK_H)
"""
from dataclasses import dataclass

from .. import config


@dataclass(frozen=True)
class Lane:
    top: int
    height: int
    track: object = None  # a track's lane
    group: object = None  # a group's header lane
    # neither: the master lane

    @property
    def bottom(self):
        return self.top + self.height


def layout(project, top=0):
    """[Lane], starting at y = top; the last one is the master lane."""
    lanes, y, current = [], top, None
    for track in project.tracks:
        if track.group is not None and track.group is not current:
            lanes.append(Lane(y, config.GROUP_H, group=track.group))
            y += config.GROUP_H
        current = track.group
        if current is not None and current.folded:
            continue
        lanes.append(Lane(y, track.height, track=track))
        y += track.height
    lanes.append(Lane(y, config.TRACK_H))
    return lanes
