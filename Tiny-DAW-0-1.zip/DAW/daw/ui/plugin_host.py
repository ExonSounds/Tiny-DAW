"""Loading VST3 plugins and opening their windows, for the GUI.

Both happen on the main thread (pedalboard's rule, see audio/plugins.py). Loading a big
instrument can take half a minute the first time; meanwhile a small "please wait" window
shows. pedalboard blocks every other plugin during a load, so the engine leaves plugins
alone for that time (Engine.plugins_paused_while): audio tracks keep playing, VST3
instrument tracks go quiet and effects are skipped until the load is done. A plugin's own
window can stay open while you keep working (Qt keeps running); one plugin window at a time.
It opens titled with the plugin's name, on screen and where it was last (plugin_windows.py).
"""
import threading
import time
import weakref

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QApplication, QInputDialog, QMessageBox, QProgressDialog

from ..audio.plugins import PluginChoiceNeeded, PluginInfo, PluginLibrary
from ..model import PluginSlot
from . import plugin_windows

FIND_MS = 15  # how often to look for the plugin's window while it opens (it shows off-screen until found)
FIND_WINDOW_S = 20  # stop looking after this long (some plugins take a while to build their window)
WATCH_MS = 250  # how often to note where the open window is


class PluginHost:
    def __init__(self, window, engine):
        self.window, self.engine = window, engine
        self._library = None
        self.open_editor = None  # (slot, close event) while a plugin window is open
        self.edited = False  # a plugin window was opened, so its settings may have changed since saving
        self.window_positions = weakref.WeakKeyDictionary()  # slot -> where its window was last (x, y)

    @property
    def library(self):
        if self._library is None:  # listing the plugin folders is quick, but only done when needed
            self._library = PluginLibrary()
        return self._library

    def busy(self, text):
        """A 'please wait' window, painted before the main thread blocks."""
        dialog = QProgressDialog(text, None, 0, 0, self.window)
        dialog.setWindowTitle("Loading plugin")
        dialog.setWindowModality(Qt.WindowModal)
        dialog.setMinimumDuration(0)
        dialog.show()
        for _ in range(5):
            QApplication.processEvents()
        return dialog

    def load(self, info):
        """A new PluginSlot with the plugin loaded, or None (after saying why)."""
        dialog = self.busy(f"Loading {info.name}…\nThe first time can take up to half a minute. Plugins pause "
                           "meanwhile;\naudio tracks keep playing (a big synth loading can make them stutter a little).")
        try:
            with self.engine.plugins_paused_while():  # other plugins would block during the load
                instance = self.library.load(info)
        except PluginChoiceNeeded as choice:
            dialog.close()
            name, ok = QInputDialog.getItem(self.window, "Choose a plugin", f"{info.name} holds several plugins:",
                                            choice.names, 0, False)
            return self.load(PluginInfo(info.path, name, None, name)) if ok else None
        except Exception as e:
            dialog.close()
            QMessageBox.warning(self.window, "Cannot load plugin", f"{info.name}\n{info.path}\n\n{e}")
            return None
        dialog.close()
        kind = "instrument" if instance.is_instrument else "effect"
        return PluginSlot(info.path, info.name, kind, info.plugin_name, instance=instance)

    def restore(self, slots):
        """Load the plugins of an opened project, with their saved settings. Returns the names of
        those that could not be loaded (they keep their settings, so saving again loses nothing)."""
        failed = []
        for i, slot in enumerate(slots, 1):
            dialog = self.busy(f"Loading plugins of the project ({i} of {len(slots)}): {slot.name}…\n"
                               "The first time can take up to half a minute each.")
            try:
                with self.engine.plugins_paused_while():  # other plugins would block during the load
                    instance = self.library.load(PluginInfo(slot.path, slot.name, slot.kind, slot.plugin_name))
                    if slot.state:
                        instance.raw_state = slot.state
                slot.instance = instance  # only now can the audio thread use it
            except Exception:
                slot.instance = None
                failed.append(slot.name)
            dialog.close()
        return failed

    def edit(self, slot, where=None):
        """Open the plugin's own window (`where`: the track's name, for its title). Returns once it is
        closed; the rest of the program keeps running."""
        if slot.instance is None:
            return
        if self.open_editor is not None:
            QMessageBox.information(self.window, "Plugin window open",
                                    f"Close the window of {self.open_editor[0].name} first.")
            return
        close = threading.Event()
        self.open_editor = (slot, close)
        self.edited = True
        placer = self.place_window_when_open(slot, slot.name if where is None else f"{slot.name} — {where}")
        try:
            slot.instance.show_editor(close)
        except Exception as e:
            QMessageBox.warning(self.window, "Cannot open plugin window", f"{slot.name}\n\n{e}")
        finally:
            placer.stop()
            self.open_editor = None

    def place_window_when_open(self, slot, name):
        """Watch for the plugin's window while show_editor() opens it (Qt timers keep running meanwhile):
        title it, put it on screen (plugin_windows.py), then keep note of where it is moved to, so it
        opens there next time. Returns the timer, to stop once the window is closed."""
        timer = QTimer(self.window)
        if not plugin_windows.available():
            return timer
        before, found, started = plugin_windows.own_windows(), [], time.monotonic()

        def tick():
            if not found:
                hwnd = plugin_windows.find_new_plugin_window(before)
                if hwnd is not None:
                    found.append(hwnd)
                    plugin_windows.place(hwnd, name, int(self.window.winId()), self.window_positions.get(slot))
                    timer.setInterval(WATCH_MS)
                elif time.monotonic() - started > FIND_WINDOW_S:
                    timer.stop()
                return
            where = plugin_windows.rect(found[0])
            if where is not None:
                self.window_positions[slot] = where[:2]

        timer.timeout.connect(tick)
        timer.start(FIND_MS)
        return timer

    def close_editor(self, slots=None):
        """Close the open plugin window (if it belongs to one of `slots`, when given)."""
        if self.open_editor and (slots is None or self.open_editor[0] in slots):
            self.open_editor[1].set()
