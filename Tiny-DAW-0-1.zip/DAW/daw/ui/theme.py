"""Colours and the dark application palette."""
from PySide6.QtGui import QColor, QPalette

# timeline
LANES = (QColor("#232529"), QColor("#282a2f"))  # alternating track lanes
MASTER_LANE = QColor("#1e2530")
MASTER_DIVIDER = QColor(70, 90, 120)
BELOW_LANES = QColor("#1d1e22")  # the timeline below the last track (the master lane is pinned over it)
GROUP_LANE = QColor("#33363e")  # a group's header lane and row, unless the group has a colour
GROUP_ACCENT = QColor(160, 160, 175)  # bar beside the rows of a group's tracks, unless it has a colour
RULER_BG = QColor(24, 25, 28)
RULER_TEXT = QColor(150, 150, 160)
GRID = QColor(55, 58, 64)
GRID_BY_STRENGTH = (QColor(45, 47, 53), GRID, QColor(72, 76, 86))  # bars and beats: finer lines, beats, bars
PLAYHEAD = QColor(255, 80, 80)  # the playback cursor
CURSOR = QColor(95, 175, 255)  # the selection cursor (where playback starts and edits happen)
FROZEN_TINT = QColor(190, 225, 255, 70)  # over the clips of a frozen track

# project overview bar
OVERVIEW_BG = QColor(20, 21, 24)
OVERVIEW_VIEW = QColor(200, 210, 225, 200)  # outline of the part the editor shows
OVERVIEW_VIEW_FILL = QColor(200, 210, 225, 28)
OVERVIEW_EDGE = QColor(55, 58, 64)  # line under the bar

# clips: default colour by kind ("audio" / "midi"). Every other clip colour (handle strip,
# waveform, notes, name, border) is derived from the fill with automatic contrast in colors.py.
CLIP_FILL = {"audio": QColor(50, 105, 150), "midi": QColor(55, 125, 85)}
TRACK_ACCENT = {"audio": QColor(80, 150, 210), "midi": QColor(90, 190, 120)}  # stripe on the panel rows

# selection
SELECTION_FILL = QColor(120, 170, 230, 45)
SELECTION_EDGE = QColor(150, 195, 245, 200)

# buttons
MUTE = QColor("#c0392b")
SOLO = QColor("#d4a017")

# meters (level meter and CPU monitor)
METER_BG = QColor(18, 19, 22)
METER_OK = QColor(70, 200, 110)
METER_WARN = QColor(220, 190, 60)
METER_HOT = QColor(220, 60, 50)

_PALETTE = {
    QPalette.Window: "#2b2d31", QPalette.WindowText: "#dcdde0",
    QPalette.Base: "#1e1f22", QPalette.AlternateBase: "#2b2d31",
    QPalette.Text: "#dcdde0", QPalette.Button: "#36383d",
    QPalette.ButtonText: "#dcdde0", QPalette.Highlight: "#3d7ab8",
    QPalette.HighlightedText: "#ffffff", QPalette.ToolTipBase: "#1e1f22",
    QPalette.ToolTipText: "#dcdde0",
}


def apply_dark_palette(app):
    app.setStyle("Fusion")
    palette = QPalette()
    for role, color in _PALETTE.items():
        palette.setColor(role, QColor(color))
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText):  # dimmed when disabled
        palette.setColor(QPalette.Disabled, role, QColor("#6b6e75"))
    app.setPalette(palette)
