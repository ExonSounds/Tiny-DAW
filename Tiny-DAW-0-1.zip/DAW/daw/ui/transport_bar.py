"""The top bar: file/track buttons, transport, time display, tempo, metronome and grid.
(The audio driver and device are chosen in Options → Audio properties…, see audio_dialog.py.)

It only creates the controls; main_window.py connects them to the timeline and engine.
"""
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QKeySequence
from PySide6.QtWidgets import QDoubleSpinBox, QLabel, QSpinBox, QToolBar, QToolButton

from .. import config
from .formatting import fmt_bars, fmt_time


class TransportBar(QToolBar):
    def __init__(self):
        super().__init__("Transport")
        self.setMovable(False)

        self.add_file_action = self.addAction("Add file…")
        self.add_file_action.setToolTip("Add audio or MIDI files (Ctrl+I)")
        self.add_file_action.setShortcut(QKeySequence("Ctrl+I"))
        self.add_audio_track_action = self.addAction("+ Audio")
        self.add_audio_track_action.setShortcut(QKeySequence("Ctrl+T"))
        self.add_audio_track_action.setToolTip("Add an audio track (Ctrl+T)")
        self.add_midi_track_action = self.addAction("+ MIDI")
        self.add_midi_track_action.setShortcut(QKeySequence("Ctrl+Shift+T"))
        self.add_midi_track_action.setToolTip("Add a MIDI track (Ctrl+Shift+T)")
        self.addSeparator()

        self.play_action = self.addAction("▶ Play")
        self.play_action.setShortcut(QKeySequence(Qt.Key_Space))
        self.start_action = self.addAction("⏮ Start")
        self.start_action.setShortcut(QKeySequence(Qt.Key_Home))
        self.follow_action = self.addAction("⇥ Follow")
        self.follow_action.setCheckable(True)
        self.follow_action.setChecked(True)
        self.follow_action.setShortcut(QKeySequence(Qt.Key_F))
        self.follow_action.setToolTip("Keep the playhead in view during playback (F)")
        self.addSeparator()

        self.time_label = QLabel()
        self.time_label.setFont(QFont("Consolas", 12))
        self.time_label.setMinimumWidth(200)
        self.time_label.setAlignment(Qt.AlignCenter)
        self.addWidget(self.time_label)
        self.addSeparator()
        self.build_timing_controls()

    def build_timing_controls(self):
        self.bpm_box = QDoubleSpinBox()
        self.bpm_box.setRange(config.MIN_BPM, config.MAX_BPM)
        self.bpm_box.setDecimals(2)
        self.bpm_box.setSuffix(" BPM")
        self.bpm_box.setKeyboardTracking(False)  # apply typed tempos on Enter, not at every digit
        self.bpm_box.setToolTip("Tempo in beats (quarter notes) per minute")
        self.addWidget(self.bpm_box)
        self.tap_button = QToolButton()
        self.tap_button.setText("Tap")
        self.tap_button.setShortcut(QKeySequence(Qt.Key_T))
        self.tap_button.setToolTip("Tap tempo (T): click in time with the music, at least twice; the BPM follows "
                                   f"the average of your last {config.TAP_COUNT} taps. A pause of "
                                   f"{config.TAP_RESET_S:g} s starts over")
        self.addWidget(self.tap_button)
        self.metronome_button = QToolButton()
        self.metronome_button.setText("Metronome")
        self.metronome_button.setCheckable(True)
        self.metronome_button.setShortcut(QKeySequence("Ctrl+M"))
        self.metronome_button.setToolTip("Metronome on/off while playing (Ctrl+M). Right-click for its sounds")
        self.metronome_button.setContextMenuPolicy(Qt.CustomContextMenu)  # main_window opens its settings
        self.metronome_button.setStyleSheet("QToolButton:checked { background: #3d7ab8; color: white; border: none; }")
        self.addWidget(self.metronome_button)
        self.signature_box = QSpinBox()
        self.signature_box.setRange(1, config.MAX_BEATS_PER_BAR)
        self.signature_box.setSuffix(" / 4")
        self.signature_box.setKeyboardTracking(False)
        self.signature_box.setToolTip("Time signature: beats per bar")
        self.addWidget(self.signature_box)
        for box in (self.bpm_box, self.signature_box):  # only take the keyboard when clicked
            box.setFocusPolicy(Qt.ClickFocus)
        self.beats_action = self.addAction("♩ Beats")
        self.beats_action.setCheckable(True)
        self.beats_action.setShortcut(QKeySequence(Qt.Key_B))
        self.beats_action.setToolTip("Edit in bars and beats (B): bar ruler and grid, clicks snap to the grid "
                                     "(hold Alt to place freely). Off: minutes and seconds")
        self.thirds_action = self.addAction("⅓ Thirds")
        self.thirds_action.setCheckable(True)
        self.thirds_action.setShortcut(QKeySequence(Qt.Key_3))
        self.thirds_action.setToolTip("Divide the grid in thirds: triplets (3)")

    def show_timing(self, timing):
        """Show the project's tempo and grid settings (without sending change signals)."""
        for widget, value in ((self.bpm_box, timing.bpm), (self.signature_box, timing.beats_per_bar),
                              (self.beats_action, timing.beats), (self.thirds_action, timing.thirds)):
            widget.blockSignals(True)
            if widget in (self.beats_action, self.thirds_action):
                widget.setChecked(value)
            else:
                widget.setValue(value)
            widget.blockSignals(False)
        self.thirds_action.setEnabled(timing.beats)

    def set_playing(self, playing):
        self.play_action.setText("⏸ Pause" if playing else "▶ Play")

    def set_time(self, seconds, timing):
        text = fmt_time(seconds)
        self.time_label.setText(f"{fmt_bars(seconds, timing)}   {text}" if timing.beats else text)
