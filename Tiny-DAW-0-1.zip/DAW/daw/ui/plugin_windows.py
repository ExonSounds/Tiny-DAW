"""Placing the windows of plugins (Windows only; elsewhere these do nothing).

pedalboard opens a plugin's window itself, as a native window with a title bar, minimize and
close buttons, but it puts the window's client area at the screen's top-left corner, so the
title bar (and with it moving, minimizing and closing) is above the screen, and it titles every
window "Pedalboard". PluginHost finds the new window while it opens and fixes both: the window
gets the plugin's name and lands fully on screen, over the main window (or where that plugin's
window was last), on the main window's monitor.

Coordinates here are physical screen pixels (Win32), as Qt makes the program DPI aware.
"""
import os
import sys

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    _user32 = ctypes.windll.user32
    _user32.MonitorFromPoint.argtypes = (wintypes.POINT, wintypes.DWORD)
    _user32.MonitorFromPoint.restype = wintypes.HMONITOR
    _user32.GetMonitorInfoW.argtypes = (wintypes.HMONITOR, ctypes.c_void_p)
    _ENUM_PROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    class _MonitorInfo(ctypes.Structure):
        _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                    ("dwFlags", wintypes.DWORD)]

PEDALBOARD_TITLE = "Pedalboard"  # what pedalboard calls every plugin window
SCREEN_MARGIN = 8  # px kept between a placed window and the edge of the screen's work area
SWP_NOSIZE, SWP_NOZORDER = 0x0001, 0x0004


def available():
    return sys.platform == "win32"


def own_windows():
    """Handles of this program's visible top-level windows."""
    if not available():
        return set()
    found, pid = set(), os.getpid()

    def add(hwnd, _):
        process = wintypes.DWORD()
        _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process))
        if process.value == pid and _user32.IsWindowVisible(hwnd):
            found.add(hwnd)
        return True

    _user32.EnumWindows(_ENUM_PROC(add), 0)
    return found


def title(hwnd):
    buffer = ctypes.create_unicode_buffer(256)
    _user32.GetWindowTextW(hwnd, buffer, 256)
    return buffer.value


def find_new_plugin_window(before):
    """The plugin window pedalboard just opened (a window that was not in `before`), or None."""
    return next((h for h in own_windows() - before if title(h) == PEDALBOARD_TITLE), None)


def rect(hwnd):
    """(left, top, width, height) of a window, or None once it is gone or while it is minimized."""
    r = wintypes.RECT()
    if _user32.IsIconic(hwnd) or not _user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def work_area_at(x, y):
    """(left, top, right, bottom) of the screen area without the taskbar, on the monitor at (x, y)
    (or the nearest one)."""
    info = _MonitorInfo()
    info.cbSize = ctypes.sizeof(_MonitorInfo)
    _user32.GetMonitorInfoW(_user32.MonitorFromPoint(wintypes.POINT(int(x), int(y)), 2), ctypes.byref(info))
    w = info.rcWork
    return w.left, w.top, w.right, w.bottom


def fit(x, y, width, height, area):
    """Top-left of a width x height window near (x, y), moved fully inside area (as far as it fits;
    a window taller than the area keeps its title bar on screen)."""
    left, top, right, bottom = area
    x = max(left + SCREEN_MARGIN, min(x, right - SCREEN_MARGIN - width))
    y = max(top + SCREEN_MARGIN, min(y, bottom - SCREEN_MARGIN - height))
    return max(x, left), max(y, top)


def place(hwnd, name, main_hwnd, last=None):
    """Title the plugin window `name` and put it fully on screen: at `last` (x, y) if given, else
    centred over the main window."""
    _user32.SetWindowTextW(hwnd, name)
    current, main = rect(hwnd), rect(main_hwnd)
    if current is None:
        return
    if main is None:  # main window minimized: centre on the primary screen instead
        left, top, right, bottom = work_area_at(0, 0)
        main = (left, top, right - left, bottom - top)
    width, height = current[2:]
    if last is not None:
        x, y = last
    else:
        x, y = main[0] + (main[2] - width) // 2, main[1] + (main[3] - height) // 3
    x, y = fit(x, y, width, height, work_area_at(x + width // 2, y + 16))  # the monitor its title bar is on
    _user32.SetWindowPos(hwnd, None, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER)
