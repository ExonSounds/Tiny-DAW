"""The plugins window of a track (FX button on its row) or of the master: the instrument (MIDI
tracks) and the chain of effects. Changes apply immediately, while playing too."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QHBoxLayout, QInputDialog, QLabel, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout)

from ..audio.plugins import EFFECT, INSTRUMENT

HINT_STYLE = "color: #9a9da5;"


def slot_label(slot):
    if slot.instance is None:
        return f"{slot.name}  (not loaded)"
    if slot.error:
        return f"{slot.name}  (stopped after an error: {slot.error})"
    return slot.name


class PluginsDialog(QDialog):
    """owner: a Track (effects in `effects`, instrument in `instrument` when it is a MIDI track) or the
    Project (effects in `master_effects`). on_change() is called after every change."""

    def __init__(self, parent, host, title, owner, effects_attr, with_instrument, on_change):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(420)
        self.host, self.owner, self.attr, self.on_change = host, owner, effects_attr, on_change
        self.where = getattr(owner, "name", "Master")  # for the plugin windows' titles
        lay = QVBoxLayout(self)

        if with_instrument:
            lay.addWidget(QLabel("<b>Instrument</b>"))
            row = QHBoxLayout()
            self.instruments = QComboBox()
            self.instruments.addItem("Built-in synth", None)
            for info in host.library.of_kind(INSTRUMENT):
                self.instruments.addItem(info.label, info)
            current = owner.instrument
            if current is not None:
                index = next((i for i in range(1, self.instruments.count())
                              if (self.instruments.itemData(i).path, self.instruments.itemData(i).plugin_name)
                              == (current.path, current.plugin_name)), -1)
                if index < 0:  # e.g. not installed any more
                    self.instruments.addItem(slot_label(current), None)
                    index = self.instruments.count() - 1
                elif current.error or current.instance is None:
                    self.instruments.setItemText(index, slot_label(current))
                self.instruments.setCurrentIndex(index)
            self.instrument_index = self.instruments.currentIndex()  # to go back to if a choice fails
            self.instruments.activated.connect(self.choose_instrument)
            row.addWidget(self.instruments, 1)
            self.edit_instrument = QPushButton("Open window")
            self.edit_instrument.clicked.connect(lambda: self.host.edit(self.owner.instrument, self.where))
            row.addWidget(self.edit_instrument)
            lay.addLayout(row)
            self.update_instrument_button()

        lay.addWidget(QLabel("<b>Effects</b> (processed top to bottom)"))
        self.list = QListWidget()
        self.list.itemChanged.connect(self.toggle_bypass)
        self.list.itemDoubleClicked.connect(lambda item: self.host.edit(self.selected(), self.where))
        lay.addWidget(self.list, 1)
        buttons = QHBoxLayout()
        for text, slot in (("Add…", self.add_effect), ("Remove", self.remove_effect), ("Up", lambda: self.move(-1)),
                           ("Down", lambda: self.move(1)), ("Open window", lambda: self.host.edit(self.selected(), self.where))):
            button = QPushButton(text)
            button.clicked.connect(slot)
            buttons.addWidget(button)
        lay.addLayout(buttons)
        hint = QLabel("Untick an effect to bypass it; double-click to open its window.\n"
                      "Plugins load on first use, which can take a while; the audio keeps playing.")
        hint.setStyleSheet(HINT_STYLE)
        lay.addWidget(hint)
        close = QDialogButtonBox(QDialogButtonBox.Close)
        close.rejected.connect(self.reject)
        lay.addWidget(close)
        self.refresh()

    # --- effects ---

    @property
    def effects(self):
        return getattr(self.owner, self.attr)

    def set_effects(self, effects):
        setattr(self.owner, self.attr, tuple(effects))  # a new tuple: the audio thread sees old or new, never half
        self.refresh()
        self.on_change()

    def refresh(self):
        self.list.blockSignals(True)
        self.list.clear()
        for slot in self.effects:
            item = QListWidgetItem(slot_label(slot))
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked if slot.bypass else Qt.Checked)
            self.list.addItem(item)
        self.list.blockSignals(False)

    def selected(self):
        row = self.list.currentRow()
        return self.effects[row] if 0 <= row < len(self.effects) else None

    def add_effect(self):
        choices = self.host.library.of_kind(EFFECT)
        label, ok = QInputDialog.getItem(self, "Add effect", "Effect:", [c.label for c in choices], 0, False)
        if not ok:
            return
        slot = self.host.load(choices[[c.label for c in choices].index(label)])
        if slot is None:
            return
        if slot.kind != EFFECT:
            QMessageBox.information(self, "Not an effect", f"{slot.name} is an instrument. Pick it as the instrument of "
                                                           "a MIDI track instead.")
            return
        self.set_effects([*self.effects, slot])
        self.list.setCurrentRow(len(self.effects) - 1)

    def remove_effect(self):
        slot = self.selected()
        if slot is not None:
            self.host.close_editor([slot])
            self.set_effects([s for s in self.effects if s is not slot])

    def move(self, step):
        row = self.list.currentRow()
        effects = list(self.effects)
        if 0 <= row < len(effects) and 0 <= row + step < len(effects):
            effects[row], effects[row + step] = effects[row + step], effects[row]
            self.set_effects(effects)
            self.list.setCurrentRow(row + step)

    def toggle_bypass(self, item):
        self.effects[self.list.row(item)].bypass = item.checkState() != Qt.Checked
        self.on_change()

    # --- instrument ---

    def choose_instrument(self, index):
        info = self.instruments.itemData(index)
        old = self.owner.instrument
        if info is None:
            if index == 0:  # "Built-in synth"
                self.host.close_editor([old] if old else [])
                self.owner.instrument = None
        else:
            slot = self.host.load(info)
            if slot is not None and slot.kind != INSTRUMENT:
                QMessageBox.information(self, "Not an instrument", f"{slot.name} is an effect. Add it under Effects instead.")
                slot = None
            if slot is None:  # back to what it was
                self.instruments.setCurrentIndex(self.instrument_index)
                return
            self.host.close_editor([old] if old else [])
            self.owner.instrument = slot
        self.instrument_index = index
        self.update_instrument_button()
        self.on_change()

    def update_instrument_button(self):
        slot = self.owner.instrument
        self.edit_instrument.setEnabled(slot is not None and slot.instance is not None)
