"""The main window: creates the project, engine and widgets, and wires them together.
Also the File menu: new, open, save (see ../project_io.py for the file format).

    +------------------------------------------+---------------+
    | File menu                                                |
    | TransportBar                                                        |
    +----------+------------------------------------------+---------------+
    | Explorer | Overview (whole project, compressed)     | caption       |
    | (dock,   +------------------------------------------+---------------+
    | View     | Timeline (in a QScrollArea)              | CpuMonitor    |
    | menu)    |   ruler                                  +---------------+
    |          |   track lanes ...                        | LanePanel     |
    |          |   master lane                            |  (scroll-     |
    |          |                                          |   synced)     |
    +----------+------------------------------------------+---------------+
"""
import os
import time

import numpy as np

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QActionGroup, QKeySequence
from PySide6.QtWidgets import (QDockWidget, QFileDialog, QFrame, QHBoxLayout, QLabel, QMainWindow, QMessageBox,
                               QScrollArea, QStyle, QVBoxLayout, QWidget)

from .. import config, project_io
from ..audio import devices
from ..audio.engine import Engine
from ..audio.metering import MASTER
from ..audio.metronome import render_click
from ..audio.plugins import sync_state
from ..model import AUDIO, MIDI, Project
from ..timing import TapTempo
from .audio_dialog import AudioPropertiesDialog
from .cpu_monitor import CpuMonitor
from .explorer import Explorer
from .lane_panel import LanePanel
from .metronome_dialog import MetronomeDialog, load_settings as load_metronome_settings
from . import theme
from .master_strip import MasterStrip
from .overview import Overview
from .plugin_dialog import PluginsDialog
from .plugin_host import PluginHost
from .preferences import REFRESH_RATES, Preferences
from .timeline import Timeline
from .track_render import TrackRenderer
from .transport_bar import TransportBar
from .widgets import PinToBottom


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.resize(1280, 800)
        self.project = Project()
        self.engine = Engine(self.project)
        self.project_path = None  # JSON file of the open project, once saved or opened
        self.prefs = Preferences.load()
        self.metronome_settings = load_metronome_settings()
        self.engine.blocksize = self.prefs.buffer_size

        self.transport = TransportBar()
        self.addToolBar(self.transport)
        self.scroll = QScrollArea()
        self.timeline = Timeline(self.project, self.engine, self.scroll)
        self.plugins = PluginHost(self, self.engine)
        self.master = MasterStrip(self.engine, self.open_master_plugins)
        self.renderer = TrackRenderer(self, self.engine, self.timeline, self.plugins)
        self.panel = LanePanel(self.project, self.timeline, self.master, self.engine.channels, self.open_track_plugins,
                               self.renderer.fill_menu)
        self.cpu_monitor = CpuMonitor()
        self.overview = Overview(self.project, self.engine, self.timeline, self.scroll)
        self.explorer = Explorer(lambda path: self.timeline.add_file(path, self.timeline.cursor), self.engine)
        self.build_layout()
        self.build_file_menu()
        self.build_view_menu()
        self.build_options_menu()
        self.connect_controls()
        self.start_timers()
        self.apply_meter_options()
        self.open_first_device()
        self.mark_saved()
        self.timeline.setFocus()  # editing keys (Space, S, Delete…) work straight away

    # --- setup ----------------------------------------------------------------------

    def build_layout(self):
        self.scroll.setFrameShape(QFrame.NoFrame)
        # always shown, so the panel's matching bottom padding is always right
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.scroll.setWidget(self.timeline)

        panel_scroll = QScrollArea()
        panel_scroll.setFrameShape(QFrame.NoFrame)
        panel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        panel_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        panel_scroll.setWidget(self.panel)
        panel_scroll.setFixedWidth(config.PANEL_W)
        # the master lane and its row stay at the bottom of the screen, over the tracks scrolling beneath
        scrollbar = self.scroll.style().pixelMetric(QStyle.PM_ScrollBarExtent)
        self.master_pins = (PinToBottom(self.timeline.master_view, self.scroll.viewport(), config.TRACK_H),
                            PinToBottom(self.master.frame, panel_scroll.viewport(), config.TRACK_H, margin=scrollbar))
        timeline_bar, panel_bar = self.scroll.verticalScrollBar(), panel_scroll.verticalScrollBar()
        timeline_bar.valueChanged.connect(panel_bar.setValue)
        panel_bar.valueChanged.connect(timeline_bar.setValue)

        left = QVBoxLayout()
        left.setSpacing(0)
        left.addWidget(self.overview)
        left.addWidget(self.scroll, 1)
        overview_caption = QLabel("Project overview")  # same height as the overview, so the rows still line up
        overview_caption.setFixedHeight(config.OVERVIEW_H)
        overview_caption.setAlignment(Qt.AlignCenter)
        overview_caption.setStyleSheet(f"color: {theme.RULER_TEXT.name()}; background: {theme.OVERVIEW_BG.name()};"
                                       f"border-bottom: 1px solid {theme.OVERVIEW_EDGE.name()};")
        right = QVBoxLayout()
        right.setSpacing(0)
        right.addWidget(overview_caption)
        right.addWidget(self.cpu_monitor)  # same height as the ruler, so the rows still line up
        right.addWidget(panel_scroll, 1)

        central = QWidget()
        row = QHBoxLayout(central)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        row.addLayout(left, 1)
        row.addLayout(right)
        self.setCentralWidget(central)

        self.explorer_dock = QDockWidget("Explorer")
        self.explorer_dock.setObjectName("explorer")
        self.explorer_dock.setWidget(self.explorer)
        self.explorer_dock.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable)
        self.explorer_dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.explorer_dock)
        self.resizeDocks([self.explorer_dock], [config.EXPLORER_W], Qt.Horizontal)

    def build_file_menu(self):
        menu = self.menuBar().addMenu("&File")
        for text, keys, slot in (("&New project", "Ctrl+N", self.new_project),
                                 ("&Open project…", "Ctrl+O", self.open_project),
                                 ("&Save", "Ctrl+S", self.save_project),
                                 ("Save &as…", "Ctrl+Shift+S", self.save_project_as),
                                 (None, None, None),
                                 ("Add audio or MIDI &file…", "Ctrl+I", self.add_files)):
            if text is None:
                menu.addSeparator()
                continue
            action = menu.addAction(text)
            action.triggered.connect(slot)
            if text.startswith("Add"):
                action.setText(f"{text}\t{keys}")  # shown only: the toolbar button owns the shortcut
            else:
                action.setShortcut(QKeySequence(keys))

    def build_view_menu(self):
        menu = self.menuBar().addMenu("&View")
        toggle = self.explorer_dock.toggleViewAction()
        toggle.setText("&Explorer")
        toggle.setShortcut(QKeySequence("Ctrl+E"))
        menu.addAction(toggle)

    def build_options_menu(self):
        """Audio properties, and options that lower CPU use; all remembered between runs."""
        menu = self.menuBar().addMenu("&Options")
        menu.addAction("&Audio properties…").triggered.connect(self.show_audio_properties)
        menu.addSeparator()

        def radio_submenu(title, choices, current, slot, tip):
            sub = menu.addMenu(title)
            sub.setToolTipsVisible(True)
            group = QActionGroup(sub)
            for value, label in choices:
                action = sub.addAction(label)
                action.setCheckable(True)
                action.setChecked(value == current)
                action.setToolTip(tip)
                action.triggered.connect(lambda _=False, v=value: slot(v))
                group.addAction(action)

        radio_submenu("Screen &refresh",
                      [(fps, f"{fps} per second") for fps in REFRESH_RATES],
                      self.prefs.refresh_fps, self.set_refresh_rate,
                      "How often the playhead and meters move. Lower: less CPU, less smooth")
        menu.addSeparator()
        for text, attr in (("&Level meters", "level_meters"), ("Loudness (&LUFS)", "loudness_meters")):
            action = menu.addAction(text)
            action.setCheckable(True)
            action.setChecked(getattr(self.prefs, attr))
            action.toggled.connect(lambda on, a=attr: self.set_meter_option(a, on))

    def show_audio_properties(self):
        p = self.prefs
        dialog = AudioPropertiesDialog(self, p.driver_type, self.device, p.buffer_size, p.wasapi_exclusive, self.engine)
        if not dialog.exec():
            return
        choice = (dialog.driver_type, dialog.device, dialog.buffer_size, dialog.exclusive)
        if choice != (p.driver_type, self.device, p.buffer_size, p.wasapi_exclusive):
            self.set_audio_device(*choice)

    def set_audio_device(self, driver_type, device, buffer_size, exclusive=False):
        """Play through `device` (a device index of `driver_type`) with `buffer_size` frames
        (0 = driver default); `exclusive` is WASAPI exclusive mode. Remembered for next time.
        Takes effect by reopening the device, which stops playback."""
        self.device = device
        p = self.prefs
        p.driver_type, p.wasapi_exclusive = driver_type, exclusive
        p.device_name = dict(devices.outputs(driver_type)).get(device, "")
        p.buffer_size = self.engine.blocksize = buffer_size
        p.save()
        if device is not None:
            self.open_device()

    def set_buffer_size(self, frames):
        p = self.prefs
        self.set_audio_device(p.driver_type, self.device, frames, p.wasapi_exclusive)

    def set_refresh_rate(self, fps):
        self.prefs.refresh_fps = fps
        self.prefs.save()
        self.frame_timer.setInterval(round(1000 / fps))

    def set_meter_option(self, attr, on):
        setattr(self.prefs, attr, on)
        self.prefs.save()
        self.apply_meter_options()

    def apply_meter_options(self):
        """Switched-off meters are hidden, and the engine stops measuring for them."""
        levels, loudness = self.prefs.level_meters, self.prefs.loudness_meters
        self.engine.metering.levels_on, self.engine.metering.loudness_on = levels, loudness
        self.panel.set_meters_visible(levels, loudness)

    def connect_controls(self):
        t = self.transport
        t.add_file_action.triggered.connect(self.add_files)
        t.add_audio_track_action.triggered.connect(lambda: self.timeline.add_track(AUDIO))
        t.add_midi_track_action.triggered.connect(lambda: self.timeline.add_track(MIDI))
        t.play_action.triggered.connect(self.toggle_play)
        t.start_action.triggered.connect(self.go_to_start)
        t.bpm_box.valueChanged.connect(lambda v: self.set_timing(bpm=v))
        t.signature_box.valueChanged.connect(lambda v: self.set_timing(beats_per_bar=v))
        t.beats_action.toggled.connect(lambda on: self.set_timing(beats=on))
        self.tap_tempo = TapTempo()
        t.tap_button.pressed.connect(self.tap)  # on press, not release: the moment of the tap counts
        t.metronome_button.setChecked(self.prefs.metronome)
        t.metronome_button.toggled.connect(self.set_metronome_on)
        t.metronome_button.customContextMenuRequested.connect(self.show_metronome_settings)
        self.apply_metronome()
        t.thirds_action.toggled.connect(lambda on: self.set_timing(thirds=on))
        for box in (t.bpm_box, t.signature_box):  # after Enter, keys (Space, S, …) go back to the timeline
            box.lineEdit().returnPressed.connect(self.timeline.setFocus)
        t.show_timing(self.project.timing)

    def tap(self):
        """Tap tempo: a tap from the Tap button (or T)."""
        bpm = self.tap_tempo.tap(time.monotonic())
        taps = len(self.tap_tempo.taps)
        if bpm is None:
            self.statusBar().showMessage("Tap tempo: keep tapping in time…", 3000)
            return
        self.transport.bpm_box.setValue(bpm)  # sets the project's tempo
        self.statusBar().showMessage(f"Tap tempo: {bpm:g} BPM from {taps} taps", 3000)

    # --- metronome --------------------------------------------------------------------------

    def set_metronome_on(self, on):
        self.prefs.metronome = on
        self.prefs.save()
        self.apply_metronome()

    def apply_metronome(self, settings=None):
        """Give the engine the metronome's sounds while it is on."""
        self.engine.set_metronome(self.metronome_settings if self.prefs.metronome else None)

    def show_metronome_settings(self):
        MetronomeDialog(self, self.metronome_settings, self.apply_metronome, self.test_click).exec()

    def test_click(self, click):
        self.engine.preview(np.repeat(render_click(click, self.engine.sr)[:, None], 2, axis=1))

    def set_timing(self, **changes):
        """Change the tempo, time signature or grid view. Clips keep their place in time."""
        for name, value in changes.items():
            setattr(self.project.timing, name, value)
        self.transport.show_timing(self.project.timing)
        self.timeline.update()

    def start_timers(self):
        self.frame_timer = QTimer(self)
        self.frame_timer.timeout.connect(self.on_frame)
        self.frame_timer.start(round(1000 / self.prefs.refresh_fps))
        self.cpu_timer = QTimer(self)
        self.cpu_timer.timeout.connect(self.on_cpu_timer)
        self.cpu_timer.start(config.CPU_REFRESH_MS)

    def open_first_device(self):
        """Open the driver type and device used last time (Options → Audio properties). If that
        driver type is gone, use the first available one (ASIO first); if the device is gone,
        that driver type's default device."""
        p = self.prefs
        available = devices.driver_types()
        if p.driver_type not in available:
            p.driver_type = available[0] if available else p.driver_type
        by_name = {name: index for index, name in devices.outputs(p.driver_type)}
        self.device = by_name.get(p.device_name, devices.default_output(p.driver_type))
        if self.device is not None:
            self.open_device()
        else:
            self.statusBar().showMessage("No audio output device found.")

    # --- actions ------------------------------------------------------------------------

    def open_device(self):
        self.stop()
        try:
            name, sr, latency = self.engine.open(self.device, exclusive=self.prefs.wasapi_exclusive)
            kind = devices.label(self.engine.driver_type) + (" exclusive" if self.engine.exclusive else "")
            buffer = "driver buffer" if not self.engine.blocksize else f"{self.engine.blocksize}-frame buffer"
            self.statusBar().showMessage(f"{kind}: {name}  ·  {self.engine.channels} outputs  ·  {sr} Hz  ·  "
                                         f"{buffer}  ·  {latency * 1000:.1f} ms output latency")
        except Exception as e:
            self.statusBar().showMessage(f"Could not open the audio device: {e}  (Options → Audio properties…)")
        self.panel.set_channels(self.engine.channels)
        self.apply_meter_options()  # the engine's metering was recreated for the device
        self.timeline.relayout()

    def add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Add audio or MIDI", "", config.FILE_FILTER)
        for path in paths:
            self.timeline.add_file(path, self.timeline.cursor)

    def go_to_start(self):
        """Both cursors to 0 s (Home)."""
        self.timeline.set_cursor(0)
        self.timeline.seek(0)

    def toggle_play(self):
        if not self.engine.stream:
            return
        if self.engine.playing:
            self.engine.stop()  # the playback cursor stays where it stopped
        else:
            self.timeline.seek(self.timeline.cursor)  # play always starts from the selection cursor
            self.engine.play()
        self.transport.set_playing(self.engine.playing)

    # --- plugins ---------------------------------------------------------------------------

    def open_track_plugins(self, track):
        if track.frozen:
            QMessageBox.information(self, "Track frozen", f"{track.name} is frozen, so its plugins are locked.\n"
                                    "Unfreeze it first (right-click its row).")
            return
        PluginsDialog(self, self.plugins, f"Plugins: {track.name}", track, "effects", track.kind == MIDI,
                      self.panel.rebuild).exec()

    def open_master_plugins(self):
        PluginsDialog(self, self.plugins, "Plugins: Master (outputs 1/2)", self.project, "master_effects", False,
                      lambda: self.master.refresh_fx(self.project.master_effects)).exec()

    def restore_plugins(self):
        """Load the plugins of a just-opened project; say which could not be loaded."""
        slots = list(self.project.plugin_slots())
        failed = self.plugins.restore(slots) if slots else []
        self.panel.rebuild()
        self.master.refresh_fx(self.project.master_effects)
        if failed:
            QMessageBox.warning(self, "Plugins missing",
                                "These plugins could not be loaded, so they are silent for now:\n\n" + "\n".join(failed) +
                                "\n\nTheir settings are kept: saving the project does not lose them.")

    # --- projects -------------------------------------------------------------------------

    def snapshot(self):
        """The project without plugin settings (see project_io.describe_slot); a plugin window being
        opened counts as a change instead (plugins.edited)."""
        return project_io.describe(self.project, self.engine.sr, self.master.settings(), states=False)

    def mark_saved(self):
        """Remember the project as it is now, to tell later whether it has unsaved changes."""
        self.saved_snapshot = self.snapshot()
        self.plugins.edited = False
        name = os.path.basename(self.project_path) if self.project_path else "Untitled"
        self.setWindowTitle(f"{name} — Tiny DAW")

    def has_unsaved_changes(self):
        return self.plugins.edited or self.snapshot() != self.saved_snapshot

    def confirm_discard(self):
        """True if it is fine to replace or close the current project (saving it first if asked)."""
        if not self.has_unsaved_changes():
            return True
        answer = QMessageBox.question(self, "Unsaved changes", "Save the changes to the current project?",
                                      QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
        if answer == QMessageBox.Save:
            return self.save_project()
        return answer == QMessageBox.Discard

    def stop(self):
        self.engine.stop()
        self.transport.set_playing(False)

    def reset_view(self):
        """After the project was replaced: empty selection, both cursors at 0, everything redrawn."""
        self.timeline.selection.clear()
        self.timeline.set_cursor(0)
        self.timeline.seek(0)
        self.timeline.relayout()
        self.timeline.tracks_changed.emit()
        self.transport.show_timing(self.project.timing)

    def new_project(self):
        if not self.confirm_discard():
            return
        self.stop()
        self.plugins.close_editor()
        self.project.clear()
        self.master.apply({})
        self.master.refresh_fx(())
        self.project_path = None
        self.reset_view()
        self.mark_saved()

    def open_project(self):
        if not self.confirm_discard():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Open project", "", "Tiny DAW project (*.json)")
        if path:
            self.open_project_file(path)

    def open_project_file(self, path):
        self.stop()
        self.plugins.close_editor()
        try:
            master = project_io.load_project(path, self.project, self.engine.sr)
        except Exception as e:
            QMessageBox.warning(self, "Cannot open project", f"{path}\n\n{e}")
            return False
        self.master.apply(master)
        self.project_path = path
        self.reset_view()
        self.restore_plugins()
        self.mark_saved()
        self.statusBar().showMessage(f"Opened {path}", 5000)
        return True

    def save_project(self):
        """Save to the current file (asks for one the first time). True if saved."""
        if not self.project_path:
            return self.save_project_as()
        return self.save_project_file(self.project_path)

    def save_project_as(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save project", self.project_path or "Untitled.json",
                                              "Tiny DAW project (*.json)")
        if not path:
            return False
        if not path.lower().endswith(".json"):
            path += ".json"
        return self.save_project_file(path)

    def save_project_file(self, path):
        if self.engine.stream is None:  # with a device open, the audio thread keeps the plugins processing (in sync)
            for slot in self.project.plugin_slots():
                sync_state(slot, self.engine.sr)
        try:
            project_io.save_project(path, self.project, self.engine.sr, self.master.settings())
        except Exception as e:
            QMessageBox.warning(self, "Cannot save project", f"{path}\n\n{e}")
            return False
        self.project_path = path
        self.mark_saved()
        self.statusBar().showMessage(f"Saved {path} (audio in {project_io.audio_folder(path)})", 5000)
        return True

    # --- periodic updates -------------------------------------------------------------

    def on_frame(self):
        """Playhead, time display, level meters and follow-scrolling."""
        tl = self.timeline
        tl.set_playhead(self.engine.pos)
        self.overview.refresh()
        shown = self.engine.pos if self.engine.playing else tl.cursor  # stopped: where Play will start
        self.transport.set_time(shown / self.engine.sr, self.project.timing)
        master_peaks, track_peaks = self.engine.metering.take_peaks()  # also queues audio for LUFS
        if self.prefs.level_meters:
            self.master.meter.push(master_peaks)
            for track, meter in self.panel.meters.items():
                meter.push(track_peaks.get(track))  # None (silent) lets the meter fall back
            for group, meter in self.panel.group_meters.items():  # a group's tracks together: the loudest
                peaks = [track_peaks[t] for t in self.project.members(group) if t in track_peaks]
                meter.push(np.max(peaks, axis=0) if peaks else None)
        if self.engine.playing:
            self.follow_playhead()

    def follow_playhead(self):
        tl = self.timeline
        hbar, view_w = self.scroll.horizontalScrollBar(), self.scroll.viewport().width()
        if tl.playhead_x > tl.width() - view_w:
            tl.relayout()  # grow the timeline as playback runs past the end
        if self.transport.follow_action.isChecked():
            # Once the playhead reaches the middle of the view, the view moves with it and keeps it
            # centred; if it is off-screen (e.g. after a seek) the view jumps to centre it.
            left, centre = hbar.value(), view_w // 2
            if tl.playhead_x > left + centre or tl.playhead_x < left:
                hbar.setValue(tl.playhead_x - centre)

    def on_cpu_timer(self):
        """CPU monitor and LUFS readouts, a few times a second."""
        load = self.engine.cpu.read(config.CPU_AVERAGE_SECONDS) if self.engine.stream else None
        self.cpu_monitor.show_load(load, self.engine.cpu.late)
        if not self.prefs.loudness_meters:
            return
        metering = self.engine.metering
        metering.update_loudness()
        self.master.loudness.show_values(*metering.read(MASTER))
        for track, display in self.panel.loudness.items():
            display.show_values(*metering.read(track))

    # --- Qt events -----------------------------------------------------------------------

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.timeline.relayout()

    def closeEvent(self, e):
        if not self.confirm_discard():
            e.ignore()
            return
        self.plugins.close_editor()
        self.engine.close()
        super().closeEvent(e)
