"""Small building blocks shared by the panel widgets."""
from PySide6.QtCore import QEvent, QObject, Qt, Signal
from PySide6.QtWidgets import QComboBox, QFrame, QLabel, QToolButton

from .. import config


def lane_frame(color, accent=None, height=config.TRACK_H, text=None):
    """A QFrame exactly one lane tall, coloured like the timeline lane next to it (or the track's colour).

    `accent` draws a stripe down the left edge (the track kind's colour); `text` colours its labels."""
    frame = QFrame()
    frame.setObjectName("lane")
    frame.setFixedHeight(height)
    border = f"3px solid {accent.name()}" if accent else "1px solid #111"
    labels = f"#lane QLabel {{ color: {text.name()}; }}" if text else ""
    frame.setStyleSheet(f"#lane {{ background: {color.name()}; border-left: {border}; }} {labels}")
    return frame


class PinToBottom(QObject):
    """Keeps `widget` across the bottom of `viewport` (a scroll area's), `margin` px above its
    bottom edge and on top of the scrolled contents, whatever the scroll position or size."""

    def __init__(self, widget, viewport, height, margin=0):
        super().__init__(viewport)
        self.widget, self.viewport, self.height, self.margin = widget, viewport, height, margin
        widget.setParent(viewport)
        viewport.installEventFilter(self)
        widget.show()
        self.place()

    def eventFilter(self, obj, e):
        if e.type() in (QEvent.Resize, QEvent.ChildAdded):
            self.place()
        return False

    def place(self):
        vp = self.viewport
        self.widget.setGeometry(0, vp.height() - self.margin - self.height, vp.width(), self.height)
        self.widget.raise_()


class NameLabel(QLabel):
    """A track's or group's name; double-click it to rename."""
    double_clicked = Signal()

    def mouseDoubleClickEvent(self, e):
        self.double_clicked.emit()


def toggle_button(text, color, checked, slot, tooltip=""):
    """Small checkable button (M / S) that lights up in `color` when on."""
    button = QToolButton()
    button.setText(text)
    button.setToolTip(tooltip)
    button.setCheckable(True)
    button.setChecked(checked)
    button.setFixedSize(26, 22)
    button.setFocusPolicy(Qt.NoFocus)
    button.setStyleSheet(f"QToolButton:checked {{ background: {color.name()}; color: white; border: none; }}")
    button.toggled.connect(slot)
    return button


class _NoWheelComboBox(QComboBox):
    """Ignores the mouse wheel, so scrolling the panel never changes a value by accident."""

    def wheelEvent(self, e):
        e.ignore()


def output_pairs(channels):
    """[(first output index, label)]: (0, "1/2"), (2, "3/4"), ...; an odd last output stands alone."""
    return [(i, f"{i + 1}/{i + 2}" if i + 1 < channels else f"{i + 1}") for i in range(0, channels, 2)]


def output_selector(channels, current, slot):
    """Combo box of the device's output pairs; calls slot(first output index) on change."""
    combo = _NoWheelComboBox()
    combo.setFocusPolicy(Qt.NoFocus)
    combo.setToolTip("Device outputs this track plays on")
    combo.setFixedWidth(58)
    for first, label in output_pairs(channels):
        combo.addItem(label, first)
    combo.setCurrentIndex(max(0, combo.findData(current)))
    combo.currentIndexChanged.connect(lambda i: slot(combo.itemData(i)))
    return combo


def plugins_summary(instrument, effects):
    """Tooltip text listing a track's (or the master's) plugins."""
    lines = [f"Instrument: {instrument.name}"] if instrument else []
    if effects:
        lines.append("Effects: " + ", ".join(s.name + (" (bypassed)" if s.bypass else "") for s in effects))
    return "\n".join(lines) if lines else "No plugins yet: click to add an instrument or effects"


def fx_button(instrument, effects, slot):
    """'FX' button opening the plugins window; lit while there are plugins."""
    button = QToolButton()
    button.setText("FX")
    button.setFixedSize(28, 22)
    button.setFocusPolicy(Qt.NoFocus)
    button.setToolTip(plugins_summary(instrument, effects))
    if instrument or effects:
        button.setStyleSheet("QToolButton { background: #3d7ab8; color: white; border: none; }")
    button.clicked.connect(slot)
    return button


def icon_button(text, slot, tooltip=""):
    button = QToolButton()
    button.setText(text)
    button.setToolTip(tooltip)
    button.setFixedSize(22, 22)
    button.setFocusPolicy(Qt.NoFocus)
    button.clicked.connect(slot)
    return button
