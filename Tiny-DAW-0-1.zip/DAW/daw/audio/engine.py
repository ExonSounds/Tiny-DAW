"""The audio output stream and the transport (play/pause, position).

The stream can use any Windows driver type: ASIO, WASAPI (shared or exclusive),
WDM-KS, DirectSound or MME (see devices.py).
_callback runs on the driver's thread; everything else on the GUI thread.
The stream uses every output channel the device has; each track plays on its own pair.
The callback mixes, runs VST3 instruments and effects (see plugins.py), and for the meters
hands copies of what played to `metering`, which measures on the GUI thread (metering.py).
It also plays the Explorer's sample preview (preview()), on outputs 1/2, playing or not, and
the metronome while playing (set_metronome(), metronome.py), after the master meters so it never
counts towards the master's level or LUFS.
"""
import gc
import threading
from contextlib import contextmanager
from time import perf_counter, sleep

import numpy as np
import sounddevice as sd

from .. import config
from . import devices
from .cpu import CpuMeter
from .metering import MASTER, Metering
from .metronome import add_clicks, render_clicks
from .mixer import mix_clips

LATE_FACTOR = 1.5  # falling this many buffers behind real time (at least) counts as a likely dropout
CLOCK_REANCHOR_S = 10.0


class PreviewVoice:
    """A sample being previewed: stereo audio at the engine rate and how far it has played."""

    def __init__(self, data):
        self.data, self.pos = data, 0


class Engine:
    def __init__(self, project):
        self.project = project
        self.sr = config.FALLBACK_SAMPLE_RATE
        self.channels = 2  # output channels of the open device
        self.blocksize = 0  # frames per buffer asked of the driver; 0 = the driver's own setting
        self.driver_type = None  # e.g. "ASIO", "Windows WASAPI" (see devices.DRIVER_TYPES), once open
        self.exclusive = False  # WASAPI exclusive mode in use
        self.pos = 0  # playhead, in frames
        self.playing = False
        self.master_gain = 1.0
        self.master_mute = False
        self.metering = Metering(self.sr, self.channels)
        self.cpu = CpuMeter()
        self.stream = None
        self._scratch = None  # one track's sum, reused every callback
        self._clock = None  # [perf_counter() reference, frames produced since], for dropout detection
        self.last_error = None  # the latest error inside the audio callback, if any (it then played silence)
        self._restart = True  # next buffer starts playback afresh (VST3 instruments: all notes off)
        self._next_pos = 0  # where the next buffer continues, if the playhead is not moved
        self._was_playing = False  # transport state at the previous buffer (a change means all notes off)
        self.plugins_paused = False  # set while a plugin loads (see plugins_paused_while)
        self.preview_voice = None  # PreviewVoice playing, or None; replaced, never changed, by the GUI thread
        self.metronome = None  # MetronomeSettings while the metronome is on, else None
        self._clicks = None  # (bar click, beat click) rendered for self.sr, while it is on; replaced, never changed
        self._lock = threading.Lock()  # guards pos between the GUI and audio threads

    def open(self, device, blocksize=None, exclusive=False):
        """Open an output device at its own sample rate with all its outputs.
        blocksize: frames per buffer (bigger = less CPU, more delay); None keeps the current choice.
        exclusive: for WASAPI devices, take the device for this program alone (lower delay).
        Returns (name, sample rate, latency in s)."""
        self.close()
        if blocksize is not None:
            self.blocksize = blocksize
        info = devices.device_info(device)
        self.driver_type = devices.driver_type_of(device)
        extra = sd.WasapiSettings(exclusive=True) if exclusive and self.driver_type == "Windows WASAPI" else None
        sr = int(info["default_samplerate"])
        if sr != self.sr:
            self.pos = self.pos * sr // self.sr
            self.project.change_sample_rate(self.sr, sr)
            self.sr = sr
            self.set_metronome(self.metronome)  # its clicks at the new rate
        self.channels = info["max_output_channels"]
        levels, loudness = self.metering.levels_on, self.metering.loudness_on
        self.metering = Metering(sr, self.channels)
        self.metering.levels_on, self.metering.loudness_on = levels, loudness
        # PortAudio sizes the driver's real buffer from the latency asked for; asking for exactly one buffer's
        # worth makes the driver use that size (otherwise it keeps its own and just cuts it into pieces).
        latency = self.blocksize / sr if self.blocksize else "low"
        if self.blocksize and self.driver_type in devices.MIN_LATENCY:
            latency = max(latency, devices.MIN_LATENCY[self.driver_type])  # these drivers starve on less
        self.stream = sd.OutputStream(device=device, samplerate=sr, dtype="float32", channels=self.channels,
                                      blocksize=self.blocksize, latency=latency, callback=self._callback,
                                      extra_settings=extra)
        self.exclusive = extra is not None
        self.cpu.reset()
        self._clock = None
        self.stream.start()
        return info["name"], sr, self.stream.latency

    def close(self):
        self.stop()
        if self.stream:
            self.stream.close()
            self.stream = None

    def seek(self, frame):
        with self._lock:
            self.pos = max(0, frame)

    def play(self):
        """Start playback. Python's full garbage collection pauses every thread for ~30 ms,
        which delays the audio callback and makes the sound hiccup; so while playing, every
        object that already exists is frozen out of it, and new garbage is cheap to scan."""
        if self.playing or not self.stream:
            return
        self.metering.reset_loudness()  # integrated LUFS covers this playback
        self.cpu.late = 0
        self._clock = None
        # (Plugins are not reset here: the audio thread keeps using them even while stopped, and a
        #  reset from this thread could clash with that. Instruments get "all notes off" instead.)
        gc.freeze()
        self.playing = True

    def preview(self, data):
        """Play `data` (stereo, engine rate) once on outputs 1/2, over whatever else plays."""
        self.preview_voice = PreviewVoice(np.ascontiguousarray(data, np.float32) * config.PREVIEW_GAIN)

    def stop_preview(self):
        self.preview_voice = None

    def set_metronome(self, settings):
        """Switch the metronome on with these sounds (MetronomeSettings), or off (None)."""
        self.metronome = settings
        self._clicks = render_clicks(settings, self.sr) if settings else None

    def stop(self):
        """Stop playback, and let the garbage collector catch up now that a pause is harmless."""
        if not self.playing:
            return
        self.playing = False
        gc.unfreeze()
        gc.collect()

    def _callback(self, out, frames, time, status):
        started = perf_counter()
        budget = frames / self.sr
        if self.playing and self.stream is not None and status is not None:  # not when called without a device
            self._check_dropout(started, frames, budget, status)
        out.fill(0)
        playing = self.playing
        plugins = not self.plugins_paused
        # VST3 plugins keep running while stopped too, like in any DAW: synths stay playable from their
        # own keyboard, reverb tails ring out, and plugins such as Serum 2 don't report "suspended".
        voice = self.preview_voice
        if playing or voice is not None or (plugins and self._has_plugins()):
            if playing:
                with self._lock:
                    start = self.pos
                    self.pos += frames
            else:
                start = None  # transport stopped: no clips, only the plugins
            # all notes off when playback starts, stops, the playhead is moved, or plugins were paused
            restart = self._restart or playing != self._was_playing or (playing and start != self._next_pos)
            if plugins:
                self._restart = False
            self._was_playing = playing
            self._next_pos = start + frames if playing else None
            if self._scratch is None or self._scratch.shape != out.shape:
                self._scratch = np.zeros_like(out)
            self._frames = frames
            metering = self.metering
            try:
                mix_clips(self.project, out, start, self._scratch, self._tap_track if metering.active else _ignore,
                          self.sr, restart, plugins)
            except Exception as e:  # never let an error stop the audio stream: play silence, remember why
                out.fill(0)
                self.last_error = f"{type(e).__name__}: {e}"
            if voice is not None:
                self._play_preview(out, voice)
            gain = 0.0 if self.master_mute else self.master_gain
            out *= gain
            if metering.active:
                metering.tap(MASTER, out.copy())
            clicks = self._clicks
            if playing and clicks is not None:
                add_clicks(out, start, clicks, self.project.timing, self.sr, gain)
        self.cpu.add(perf_counter() - started, budget)

    def _play_preview(self, out, voice):
        """Add the next buffer of the preview to outputs 1/2 (audio thread); forget it once done."""
        chunk = voice.data[voice.pos:voice.pos + len(out)]
        width = min(2, out.shape[1])
        out[:len(chunk), :width] += chunk[:, :width]
        voice.pos += len(out)
        if voice.pos >= len(voice.data) and self.preview_voice is voice:
            self.preview_voice = None

    @contextmanager
    def plugins_paused_while(self):
        """Use around loading a plugin: pedalboard holds a global lock while loading, so any other
        plugin the audio thread calls meanwhile would block it for the whole load (measured: buffers
        taking 3x their time, constant dropouts). Instead, plugins are left alone for that time; audio
        tracks keep playing. Afterwards instruments get "all notes off", as their notes were missed."""
        self.plugins_paused = True
        sleep(0.05)  # let a callback that is already running finish with its plugins
        try:
            yield
        finally:
            self._restart = True
            self.plugins_paused = False

    def _has_plugins(self):
        return any(slot.instance is not None for slot in self.project.plugin_slots())

    def _check_dropout(self, now, frames, budget, status):
        """Count likely clicks for the CPU monitor: PortAudio reported an underflow, or the audio
        produced has fallen behind real time by more than the device had queued, so it ran dry.
        Comparing totals rather than the gap between two callbacks copes with drivers that call
        in bursts (WASAPI exclusive) or with uneven buffer sizes (DirectSound)."""
        if self._clock is None or now - self._clock[0] > CLOCK_REANCHOR_S:
            # (time, frames produced) since a reference point; renewed now and then so the slight
            # drift between the audio device's clock and the PC's never adds up to a false alarm
            self._clock = [now, 0]
        start, produced = self._clock
        behind = (now - start) - produced / self.sr
        if status.output_underflow or behind > max(LATE_FACTOR * budget, self.stream.latency):
            self.cpu.late += 1
            self._clock = [now, 0]  # the device has re-synchronised; measure from here
        self._clock[1] += frames

    def _tap_track(self, track, block, first, channels):
        """Called by mix_clips for every track: hand a copy of its own outputs to the meters."""
        if block is None:  # silent in this buffer
            self.metering.tap_silence(track, self._frames)
        else:
            self.metering.tap(track, block[:, first:first + channels].copy(), first)


def _ignore(*args):
    pass
