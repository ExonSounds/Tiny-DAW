"""Rendering a track to audio offline, for freezing and bouncing it. No Qt.

A track renders the way it plays: its clips, through its VST3 instrument on a MIDI track (else
the built-in synth's audio), then its effects. Not included: mute, solo, its group, the master
volume and master effects. The rendering runs from the track's first clip to its last clip's
end, plus up to RENDER_TAIL_S while plugins may still ring out (cut once the sound has died away).

It calls the track's plugins from this (the main) thread, so the audio thread must leave them
alone meanwhile (Engine.plugins_paused_while; see plugins.py). They are reset first, so a
rendering never starts with what they were playing live.
"""
import numpy as np

from .. import config
from .mixer import add_clip
from .plugins import note_messages, run_effects, usable


def render_track(project, track, sr, progress=None):
    """(start frame, stereo float32 audio (frames, 2)) of the track, or None if it has no clips
    that play (disabled clips are left out).
    progress(fraction done) is called now and then; if it returns False, rendering stops and
    None is returned. Raises if its instrument fails."""
    clips = [c for c in project.clips_on(track) if not c.disabled]
    if not clips:
        return None
    instrument = track.instrument if track.kind == "midi" and usable(track.instrument) else None
    effects = [s for s in track.effects if usable(s) and not s.bypass]
    plugins = ([instrument] if instrument else []) + effects
    # EDGE_FADE_FRAMES of silence on both sides: a clip made of the rendering fades in and out over
    # them (mixer.add_clip), so it plays exactly like the track did (unless it starts at 0 s)
    pad = config.EDGE_FADE_FRAMES
    start = max(0, min(c.start for c in clips) - pad)
    last_note = max(c.end for c in clips)
    end = last_note + (round(config.RENDER_TAIL_S * sr) if plugins else 0) + pad
    block = config.RENDER_BLOCK
    for slot in plugins:
        slot.instance.reset()
        slot.pending = None
    out = np.zeros((end - start, 2), np.float32)
    try:
        for i, pos in enumerate(range(start, end, block)):
            n = min(block, end - pos)
            buf = out[pos - start:pos - start + n]  # a view: written in place
            if instrument:
                audio = instrument.instance(note_messages(clips, pos, n, sr, restart=pos == start), duration=n / sr,
                                            sample_rate=sr, num_channels=2, buffer_size=block, reset=False)
                m = min(n, audio.shape[1])
                buf[:m] += audio[:2, :m].T
            else:
                for clip in clips:
                    add_clip(buf, clip, pos, 0)
            run_effects(track.effects, buf, sr)
            if progress and i % 32 == 0 and progress((pos - start) / (end - start)) is False:
                return None
    finally:
        for slot in plugins:
            slot.pending = None  # the audio thread starts afresh with them
    # cut the tail where it has died away (keeping the silent pad)
    loud = np.flatnonzero(np.abs(out[last_note - start:]).max(axis=1) > config.RENDER_SILENCE)
    out = out[:last_note - start + (loud[-1] + 1 if len(loud) else 0) + pad]
    return start, out
