"""VST3 plugins (instruments and effects), hosted through Spotify's pedalboard library.

Rules found by testing pedalboard on Windows (they shape the rest of the program):
  - Load plugins and open their windows on the main thread only. Loading can take 10-35 s
    for big instruments. It releases the GIL, but holds a lock that blocks every other plugin's
    processing for that whole time, so the engine pauses plugins while one loads
    (Engine.plugins_paused_while); audio tracks keep playing.
  - While a plugin's window is open, Qt keeps running (they share the Windows message queue).
  - From the audio thread only ever process with reset=False; hanging notes are cleared with
    MIDI "all notes off" messages instead.
  - Plugins are processed continuously while the audio device is open, playing or not (as DAWs
    do): otherwise synths like Serum 2 show "DAW suspended audio processing", can't be played
    from their own keyboard, and effect tails freeze. So the main thread never processes or
    resets a plugin while a device is open.

Finding plugins is instant: the VST3 folders are listed, and each plugin's kind (instrument or
effect) comes from the bundle's moduleinfo.json or, failing that, from a cache filled the first
time each plugin is loaded (plugin_cache.json in %APPDATA%\\TinyDAW).
"""
import glob
import json
import os
import re
from dataclasses import dataclass

import numpy as np
from mido import Message

DEFAULT_FOLDERS = (r"C:\Program Files\Common Files\VST3",
                   os.path.expandvars(r"%LOCALAPPDATA%\Programs\Common\VST3"))
CACHE_PATH = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "TinyDAW", "plugin_cache.json")
INSTRUMENT, EFFECT = "instrument", "effect"

# sent to an instrument when playback starts or jumps: "all sound off" and "all notes off" on every channel
ALL_NOTES_OFF = [Message("control_change", channel=ch, control=cc, value=0) for ch in range(16) for cc in (120, 123)]


@dataclass(frozen=True)
class PluginInfo:
    path: str  # the file to load (the one inside a bundle folder, if it is a bundle)
    name: str
    kind: str = None  # INSTRUMENT, EFFECT, or None until the plugin has been loaded once
    plugin_name: str = None  # which plugin, for files that hold several (e.g. "Serum 2" / "Serum 2 FX")

    @property
    def label(self):
        return self.name if self.kind else f"{self.name}  (type not known yet)"


class PluginChoiceNeeded(Exception):
    """The file holds several plugins; `names` lists them."""

    def __init__(self, names):
        super().__init__(", ".join(names))
        self.names = names


def loadable_file(path):
    """For a bundle folder (X.vst3/Contents/x86_64-win/X.vst3) the inner file; pedalboard can't scan the folder."""
    inner = os.path.join(path, "Contents", "x86_64-win", os.path.basename(path))
    return inner if os.path.isdir(path) and os.path.isfile(inner) else path


def read_moduleinfo(bundle):
    """[(name, kind)] from a bundle's moduleinfo.json (JSON5-ish: comments, trailing commas), or None."""
    info = os.path.join(bundle, "Contents", "Resources", "moduleinfo.json")
    if not os.path.isfile(info):
        return None
    try:
        text = open(info, encoding="utf-8-sig").read()
        text = re.sub(r"(?m)^\s*//[^\n]*", "", text)
        text = re.sub(r",(\s*[}\]])", r"\1", text)
        classes = json.loads(text, strict=False).get("Classes", [])
    except (OSError, ValueError):
        return None
    found = [(c["Name"], INSTRUMENT if any("Instrument" in s for s in c.get("Sub Categories", [])) else EFFECT)
             for c in classes if c.get("Category") == "Audio Module Class"]
    return found or None


class PluginLibrary:
    """The VST3 plugins on this computer. `plugins` is filled instantly; kinds become known as described above."""

    def __init__(self, folders=DEFAULT_FOLDERS, cache_path=CACHE_PATH):
        self.folders, self.cache_path = folders, cache_path
        try:
            self.cache = json.load(open(cache_path, encoding="utf-8"))
        except (OSError, ValueError):
            self.cache = {}
        self.plugins = self.scan()

    def scan(self):
        found = []
        for folder in self.folders:
            for path in sorted(glob.glob(os.path.join(folder, "**", "*.vst3"), recursive=True)):
                if os.sep + "Contents" + os.sep in path:
                    continue  # the inner file of a bundle: listed through the bundle
                file = loadable_file(path)
                stem = os.path.splitext(os.path.basename(path))[0]
                cached = self.cache.get(file)
                if cached and cached.get("mtime") == os.path.getmtime(file):
                    found += [PluginInfo(file, e["name"], e["kind"], e["plugin_name"]) for e in cached["plugins"]]
                    continue
                classes = read_moduleinfo(path) if os.path.isdir(path) else None
                if classes and len(classes) > 1:
                    found += [PluginInfo(file, name, kind, name) for name, kind in classes]
                elif classes:
                    found.append(PluginInfo(file, classes[0][0], classes[0][1]))
                else:
                    found.append(PluginInfo(file, stem))
        return sorted(found, key=lambda p: p.name.lower())

    def of_kind(self, kind):
        """Plugins of that kind, plus those whose kind is not known yet."""
        return [p for p in self.plugins if p.kind in (kind, None)]

    def load(self, info):
        """Load a plugin (main thread only). Learns and remembers its kind. Raises on failure."""
        import pedalboard  # imported here: it is slow to import and only needed once plugins are used
        try:
            plugin = pedalboard.load_plugin(info.path, plugin_name=info.plugin_name)
        except Exception:
            if info.plugin_name is None:
                names = pedalboard.VST3Plugin.get_plugin_names_for_file(info.path)
                if len(names) > 1:
                    self.remember(info.path, [PluginInfo(info.path, n, None, n) for n in names])
                    raise PluginChoiceNeeded(names)
            raise
        kind = INSTRUMENT if plugin.is_instrument else EFFECT
        if info.kind != kind:
            same_file = [p for p in self.plugins if p.path == info.path and p != info]
            self.remember(info.path, same_file + [PluginInfo(info.path, info.name, kind, info.plugin_name)])
        return plugin

    def remember(self, file, infos):
        self.cache[file] = {"mtime": os.path.getmtime(file),
                            "plugins": [{"name": p.name, "kind": p.kind, "plugin_name": p.plugin_name} for p in infos]}
        try:
            os.makedirs(os.path.dirname(self.cache_path), exist_ok=True)
            json.dump(self.cache, open(self.cache_path, "w", encoding="utf-8"), indent=1)
        except OSError:
            pass  # only a cache
        self.plugins = sorted([p for p in self.plugins if p.path != file] + infos, key=lambda p: p.name.lower())


def sync_state(slot, sr, frames=512):
    """Have the plugin copy its latest settings into its saved state. A VST3 plugin's window and its
    sound engine are separate parts; changes pass from one to the other only while it processes
    audio. The audio thread processes plugins all the time while a device is open; without one,
    this processes one silent buffer (main thread only, never while the audio thread uses the plugin)."""
    if slot.instance is None or slot.error is not None:
        return
    if slot.kind == INSTRUMENT:
        slot.instance([], duration=frames / sr, sample_rate=sr, num_channels=2, buffer_size=frames, reset=False)
    else:
        slot.instance.process(np.zeros((2, frames), np.float32), sr, buffer_size=frames, reset=False)


# --- audio thread ---------------------------------------------------------------------------

def usable(slot):
    return slot is not None and slot.instance is not None and slot.error is None


def play_instrument(slot, messages, out, sr):
    """Render one buffer of an instrument plugin and add it into out (frames, channels)."""
    frames = len(out)
    try:
        audio = slot.instance(messages, duration=frames / sr, sample_rate=sr, num_channels=2,
                              buffer_size=frames, reset=False)
    except Exception as e:  # a failing plugin is switched off, never the whole audio stream
        slot.error = str(e) or type(e).__name__
        return
    n = min(frames, audio.shape[1])
    out[:n] += audio[:out.shape[1], :n].T


def run_effects(slots, signal, sr):
    """Process signal (frames, channels: a view) through the active effects, in place."""
    active = [s for s in slots if usable(s) and not s.bypass]
    if not active:
        return
    frames, channels = signal.shape
    x = np.ascontiguousarray(signal.T if channels == 2 else np.repeat(signal[:, :1].T, 2, axis=0))
    for slot in active:
        try:
            y = slot.instance.process(x, sr, buffer_size=frames, reset=False)
        except Exception as e:
            slot.error = str(e) or type(e).__name__
            continue
        x = exactly(slot, y, frames)
    signal[:] = x[:channels].T


def exactly(slot, y, frames):
    """`frames` frames of a plugin's output. Plugins with look-ahead (limiters, linear-phase EQs) can give
    fewer frames than they were given at first, or more later; the difference is kept in slot.pending,
    and a shortfall at the very start is filled with silence (so such a plugin delays its track a little)."""
    if slot.pending is not None and slot.pending.shape[1]:
        y = np.concatenate([slot.pending, y], axis=1)
    if y.shape[1] >= frames:
        slot.pending = y[:, frames:]
        return y[:, :frames]
    slot.pending = None
    return np.concatenate([np.zeros((y.shape[0], frames - y.shape[1]), y.dtype), y], axis=1)


def note_messages(clips, start, frames, sr, restart=False):
    """MIDI messages for the notes of `clips` that start or end in timeline frames [start, start+frames),
    timed in seconds from the buffer start. Notes are cut at the end of each clip's window.
    start=None (transport stopped): no notes, only "all notes off" on a restart."""
    events = []
    end = start + frames if start is not None else None
    for clip in clips if start is not None else ():
        on, off, pitch, velocity = clip.events.T
        lo, hi = clip.offset, clip.offset + clip.frames
        inside = (on >= lo) & (on < hi)  # notes that start within the clip's window
        t_on = clip.start + on - lo
        t_off = clip.start + np.minimum(off, hi) - lo
        starts = inside & (t_on >= start) & (t_on < end)
        stops = inside & (t_off >= start) & (t_off < end)
        events += [(t - start, 1, int(p), max(1, int(v))) for t, p, v in zip(t_on[starts], pitch[starts], velocity[starts])]
        events += [(t - start, 0, int(p), 0) for t, p in zip(t_off[stops], pitch[stops])]
    events.sort()  # by time; note-offs before note-ons at the same moment
    messages = list(ALL_NOTES_OFF) if restart else []
    messages += [Message("note_on" if is_on else "note_off", note=p, velocity=v, time=t / sr)
                 for t, is_on, p, v in events]
    return messages
