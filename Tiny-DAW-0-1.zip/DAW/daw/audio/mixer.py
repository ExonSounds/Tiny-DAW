"""Summing clips into an output buffer. Runs on the audio thread, so keep it allocation-light."""
import numpy as np

from .. import config
from .plugins import note_messages, play_instrument, run_effects, usable


def mix_clips(project, out, start, scratch, on_track, sr, restart=False, plugins=True):
    """Add every audible track's sound for frames [start, start + len(out)) into out.

    Each track is summed in `scratch` (same shape as out) on its own output pair
    (track.output): its clips' audio, or, on a MIDI track with a VST3 instrument, the
    instrument playing the clips' notes; then its effects. A frozen track plays its rendering
    (track.frozen) instead, without calling its plugins. on_track(track, scratch, first,
    channels) is called so the engine can meter it: the track's sound is in
    scratch[:, first:first + channels]. For a track that is silent in this buffer (no clips
    and no plugins that could still ring, muted, or not soloed) on_track(track, None, 0, 0)
    is called instead. start=None: the transport is stopped, so only the plugins run (no clips).
    `restart`: playback just started, stopped or jumped; instruments get "all notes off" first.
    plugins=False: don't call any plugin (one is being loaded, which would block them): tracks
    with a VST3 instrument are silent and effects are skipped.
    """
    frames = len(out)
    by_track = {}
    if start is not None:
        end = start + frames
        for clip in project.clips:
            # >= : a note-off can fall exactly on a MIDI clip's end
            if clip.start < end and clip.end >= start and not clip.disabled:
                by_track.setdefault(clip.track, []).append(clip)
    for track in project.tracks:
        clips = by_track.get(track, ())
        frozen = track.frozen
        vst_instrument = track.kind == "midi" and usable(track.instrument)
        instrument = track.instrument if vst_instrument and plugins else None
        has_plugins = plugins and (instrument is not None or any(usable(s) and not s.bypass for s in track.effects))
        if frozen is not None:  # frozen: its rendering plays instead of its clips and plugins
            clips = (frozen,) if start is not None and frozen.start < start + frames and frozen.end > start else ()
            vst_instrument, instrument, has_plugins = False, None, False
        if not project.audible(track) or not (clips or has_plugins) or (vst_instrument and not plugins):
            on_track(track, None, 0, 0)
            continue
        scratch.fill(0)
        first = track.output if track.output < out.shape[1] else 0  # device lacks that output: use 1/2
        channels = min(2, out.shape[1] - first)
        signal = scratch[:, first:first + channels]
        if instrument is not None:  # keeps rendering even without notes, so releases ring out
            play_instrument(instrument, note_messages(clips, start, frames, sr, restart), signal, sr)
        else:
            for clip in clips:
                add_clip(scratch, clip, start, first)
        if plugins and frozen is None:
            run_effects(track.effects, signal, sr)
        on_track(track, scratch, first, channels)
        out += scratch
    if plugins:
        run_effects(project.master_effects, out[:, :min(2, out.shape[1])], sr)


def add_clip(buf, clip, start, first_channel=0):
    """Add the part of clip that falls in buf (which starts at timeline frame `start`).

    Clips are stereo and play on channels first_channel and first_channel + 1 (only the
    left one if the device has no channel after it).
    """
    cs, frames = clip.start, clip.frames
    a, b = max(start, cs), min(start + len(buf), cs + frames)
    if a >= b:
        return
    i0, i1 = a - cs, b - cs  # positions inside the clip window
    channels = min(buf.shape[1] - first_channel, clip.data.shape[1])
    segment = clip.data[clip.offset + i0:clip.offset + i1, :channels]
    fade = config.EDGE_FADE_FRAMES
    if i0 < fade or i1 > frames - fade:  # short fade at the clip's edges, so cuts don't click
        pos = np.arange(i0, i1)
        segment = segment * np.minimum(1.0, np.minimum(pos + 1, frames - pos) / fade)[:, None]
    buf[a - start:b - start, first_channel:first_channel + channels] += segment
