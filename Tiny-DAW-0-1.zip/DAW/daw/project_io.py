"""Saving and loading projects. No GUI code.

A saved project is a JSON file plus a folder next to it named "<name>_audio":

    MySong.json
    MySong_audio/
        drums.wav
        vocals.wav

The folder holds the audio of every audio clip as 32-bit float WAV, exactly what the
program plays from (whatever format it was imported from). Split clips share one file.
Saving again reuses files already in the folder and never overwrites or deletes any.
MIDI notes are stored in the JSON itself. Times are in seconds, so a project opens at
any sample rate. The tempo, time signature and grid view are stored under "timing".

VST3 plugins are stored by their file path plus their settings (base64 of the plugin's own
state); the plugins themselves stay where they are installed. load_project() only restores
these PluginSlots: loading the plugins is the GUI's job, on the main thread (audio/plugins.py).
"""
import base64
import json
import os
import re
from dataclasses import asdict, fields

import numpy as np
import soundfile as sf

from . import config
from .audio.file_io import load_audio
from .model import AUDIO, GROUP, MIDI, AudioClip, Group, MidiClip, PluginSlot, Track
from .timing import Timing

FORMAT, VERSION = "tinydaw-project", 1
TRACK_FIELDS = ("name", "kind", "muted", "soloed", "output", "height", "color", "tone")
SLOT_FIELDS = ("path", "name", "kind", "plugin_name", "bypass")
GROUP_FIELDS = ("name", "folded", "muted", "soloed", "color", "tone")


def describe_slot(slot, states=True):
    """states=False leaves out the plugin's settings: some plugins describe the same settings with
    different bytes each time, so they can't tell whether anything changed (see describe())."""
    state = slot.current_state() if states else None
    return {**{f: getattr(slot, f) for f in SLOT_FIELDS},
            "state": base64.b64encode(state).decode("ascii") if state else None}


def read_slot(entry):
    state = entry.get("state")
    return PluginSlot(**{f: entry[f] for f in SLOT_FIELDS if f in entry},
                      state=base64.b64decode(state) if state else None)


def describe_track(track, groups, sr, audio_file, states=True):
    """groups: the project's groups in order; the track names its group by index. A frozen track
    names the file of its rendering (audio_file, as for clips)."""
    frozen = track.frozen
    return {**{f: getattr(track, f) for f in TRACK_FIELDS},
            "group": groups.index(track.group) if track.group else None,
            "frozen": {"file": audio_file(frozen), "start": frozen.start / sr} if frozen else None,
            "instrument": describe_slot(track.instrument, states) if track.instrument else None,
            "effects": [describe_slot(s, states) for s in track.effects]}


def audio_folder(json_path):
    stem = os.path.splitext(os.path.basename(json_path))[0]
    return os.path.join(os.path.dirname(os.path.abspath(json_path)), f"{stem}_audio")


def describe(project, sr, master, audio_file=lambda clip: id(clip.source), states=True):
    """The project as a JSON-ready dict. `audio_file(clip)` names each audio clip's file;
    by default it is the identity of its audio, which is enough to tell whether anything changed.
    states=False leaves out plugin settings (for telling whether anything changed)."""
    rows, groups = project.rows(), project.groups()
    clips = []
    for clip in project.clips:
        entry = {"kind": clip.kind, "name": clip.name, "track": rows[clip.track],
                 "start": clip.start / sr, "offset": clip.offset / sr,
                 "length": None if clip.length is None else clip.length / sr,
                 "color": clip.color, "tone": clip.tone, "disabled": clip.disabled}
        if clip.kind == AUDIO:
            entry["file"] = audio_file(clip)
        else:
            entry["notes"] = clip.notes.tolist()  # [start s, end s, pitch, velocity]
            entry["midi_length"] = clip.length_s
        clips.append(entry)
    return {"format": FORMAT, "version": VERSION, "master": master, "tracks_made": dict(project.tracks_made),
            "timing": asdict(project.timing),
            "groups": [{f: getattr(g, f) for f in GROUP_FIELDS} for g in groups],
            "tracks": [describe_track(t, groups, sr, audio_file, states) for t in project.tracks], "clips": clips,
            "master_effects": [describe_slot(s, states) for s in project.master_effects]}


def save_project(path, project, sr, master):
    """Write the JSON and any audio not yet in the project's audio folder."""
    folder = audio_folder(path)
    os.makedirs(folder, exist_ok=True)
    folder_name = os.path.basename(folder)

    # Audio clips, and the renderings of frozen tracks
    audio = [c for c in project.clips if c.kind == AUDIO] + [t.frozen for t in project.tracks if t.frozen]
    # Audio already saved in this folder (from an earlier save or load) is reused as is.
    files = {}  # id(source) -> file name in the folder
    for clip in audio:
        p = clip.source_path
        if p and os.path.dirname(os.path.abspath(p)) == folder and os.path.exists(p):
            files[id(clip.source)] = os.path.basename(p)
    # Everything else is written as a new file, never over an existing one.
    for clip in audio:
        if id(clip.source) not in files:
            name = unique_file_name(folder, clip.name)
            sf.write(os.path.join(folder, name), clip.source, clip.source_sr, subtype="FLOAT")
            files[id(clip.source)] = name
    for clip in audio:
        clip.source_path = os.path.join(folder, files[id(clip.source)])

    data = describe(project, sr, master, lambda clip: f"{folder_name}/{files[id(clip.source)]}")
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(temp, path)  # a crash mid-save never leaves a half-written project


def unique_file_name(folder, clip_name):
    stem = re.sub(r"[^\w\- ]+", "_", os.path.splitext(clip_name)[0]).strip() or "audio"
    name, n = f"{stem}.wav", 2
    while os.path.exists(os.path.join(folder, name)):
        name, n = f"{stem} ({n}).wav", n + 1
    return name


def load_project(path, project, sr):
    """Fill `project` from the file at `path`, preparing clips for sample rate sr.

    Returns the master settings. Everything is read before `project` is touched, so a
    broken or incomplete project raises and leaves the current one as it was.
    """
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if data.get("format") != FORMAT:
        raise ValueError("This is not a Tiny DAW project file.")
    base = os.path.dirname(os.path.abspath(path))
    groups = [Group(**{f: g[f] for f in GROUP_FIELDS if f in g}) for g in data.get("groups", ())]
    tracks = [Track(**{f: t[f] for f in TRACK_FIELDS if f in t},
                    group=groups[t["group"]] if t.get("group") is not None else None,
                    instrument=read_slot(t["instrument"]) if t.get("instrument") else None,
                    effects=tuple(read_slot(s) for s in t.get("effects", ())))
              for t in data["tracks"]]
    for track, entry in zip(tracks, data["tracks"]):
        frozen = entry.get("frozen")
        file = os.path.normpath(os.path.join(base, frozen["file"])) if frozen else None
        if file and os.path.exists(file):  # (its file missing: the track opens unfrozen, playing live)
            source, source_sr = load_audio(file)
            track.frozen = AudioClip(name=f"{track.name} (frozen)", track=track, start=round(frozen["start"] * sr),
                                     source=source, source_sr=source_sr, source_path=file)
            track.frozen.prepare(sr)

    sources, missing, clips = {}, [], []  # sources: file path -> (audio, rate), loaded once and shared
    for entry in data["clips"]:
        common = dict(name=entry["name"], track=tracks[entry["track"]], start=round(entry["start"] * sr),
                      offset=round(entry["offset"] * sr),
                      length=None if entry["length"] is None else round(entry["length"] * sr),
                      color=entry.get("color"), tone=entry.get("tone"), disabled=entry.get("disabled", False))
        if entry["kind"] == AUDIO:
            file = os.path.normpath(os.path.join(base, entry["file"]))
            if not os.path.exists(file):
                missing.append(entry["file"])
                continue
            if file not in sources:
                sources[file] = load_audio(file)
            source, source_sr = sources[file]
            clip = AudioClip(source=source, source_sr=source_sr, source_path=file, **common)
        else:
            notes = np.array(entry["notes"], dtype=np.float64).reshape(-1, 4)
            clip = MidiClip(notes=notes, length_s=entry["midi_length"], **common)
        clip.prepare(sr)
        clips.append(clip)
    if missing:
        raise FileNotFoundError("Audio files are missing:\n" + "\n".join(missing))
    timing = read_timing(data.get("timing", {}))

    project.tracks, project.clips = tuple(tracks), tuple(clips)
    project.master_effects = tuple(read_slot(s) for s in data.get("master_effects", ()))
    made = data.get("tracks_made", {})
    project.tracks_made = {AUDIO: made.get(AUDIO, 0), MIDI: made.get(MIDI, 0), GROUP: made.get(GROUP, len(groups))}
    project.gather_groups()
    project.timing = timing
    return data.get("master", {})


def read_timing(entry):
    """A Timing from a project's "timing" entry; missing or out-of-range values get the defaults."""
    timing = Timing(**{f.name: entry[f.name] for f in fields(Timing) if f.name in entry})
    if not config.MIN_BPM <= timing.bpm <= config.MAX_BPM:
        timing.bpm = config.DEFAULT_BPM
    if not 1 <= timing.beats_per_bar <= config.MAX_BEATS_PER_BAR:
        timing.beats_per_bar = config.DEFAULT_BEATS_PER_BAR
    return timing
